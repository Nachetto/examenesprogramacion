package common;

public class Constantes {
    public static final String PISTASINICIALES = "Error al cargar las pistas iniciales porque: ";
    public static final String ERRORSKIFONDO = "ERROR: la pista no es de ski de fondo";
    public static final String EXCEPCION="La Dificultad tiene que ser o azul, o roja o verde";
    public static final String ERRORFICHERO = "Error al cargar el fichero";
    public static final String ERRORBINARIO = "Error al cargar el binario";
}
